<p align="right">
  <a><img title="Built With Love" src="https://forthebadge.com/images/badges/uses-html.svg" ></a>
 </p>

![20200316_174935_0000](https://user-images.githubusercontent.com/55870659/79133536-08bb1700-7d61-11ea-84a0-8e7fcbb70392.png)
<p align="center">
<a href="https://github.com/Ignitetch/AdvPhishing/releases"><img title="GitHub version" src="https://img.shields.io/badge/version-2.0-blue" ></a>  
</p>

<p align="center">
  <b> Follow on Social Media Platforms </b>
</p>
<p align="center">
<a href="https://www.facebook.com/profile.php?id=100016971998117"><img title="GitHub version" src="https://img.shields.io/badge/-Facebook-blue" ></a> <a href="https://www.youtube.com/channel/UCfBDWui9dSRbCmT32jf848Q"><img title="GitHub version" src="https://img.shields.io/badge/-youtube-red" ></a> <a href="https://www.linkedin.com/in/shubham-goyal-sgpro"><img title="GitHub version" src="https://img.shields.io/badge/-Linkedin-green" ></a>
</p>
<p align="center">
  <b> Contribute us</b>
</p>
<p align="center">
<a href="https://www.paypal.com/paypalme2/Goyal827"><img title="GitHub version" src="https://camo.githubusercontent.com/ae8af018f80649f3d379eb23dbf59acceaffa24e/68747470733a2f2f6c69626572617061792e636f6d2f6173736574732f776964676574732f646f6e6174652e737667"></a>
</p>

# Here is Best Tutorial with Good Explaination
Link - https://secnhack.in/advphishing-otp-bypass-phishing-tool/

# TECHNIQUE
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

# TUTORIAL [ KALI ]
[(![des](https://user-images.githubusercontent.com/55870659/77065337-7b7de000-69b7-11ea-915d-4dad81d2e892.png)](https://www.youtube.com/watch?v=MhSb4My1lZo)

# TUTORIAL [ TERMUX ]
[(![des](https://user-images.githubusercontent.com/55870659/79192397-73119d00-7ddd-11ea-865f-9128abe2fba9.jpg)](https://www.youtube.com/watch?v=LO3hX1lLBjI)

# MORE TUTORIALS 
* GOOGLE OTP - https://youtu.be/MhSb4My1lZo
* Installation - https://www.youtube.com/watch?v=Yv5tT-hmcYQ
* PAYTM OTP - https://www.youtube.com/watch?v=3TB_sISTw9U
* TIKTOK -    https://www.youtube.com/watch?v=5qc0Mgyhr7E

# SCREENSHOT ( KALI )
![full](https://user-images.githubusercontent.com/55870659/79147250-a7f80280-7d91-11ea-894a-d7d685a6e8cb.png)


# INSTALLATION [ TERMUX APP --ANDROID ]
* git clone https://github.com/Ignitetch/AdvPhishing.git
* cd AdvPhishing/
* chmod 777 start.sh
* ./start.sh
* ./An-AdvPhishing.sh

# INSTALLATION [ KALI ]
* git clone https://github.com/Ignitetch/AdvPhishing.git
* cd AdvPhishing/
* chmod 777 setup.sh
* ./setup.sh
* ./AdvPhishing.sh

# AVAILABLE TUNNELLING OPTIONS
1. LOCALHOST
2. NGROK (https://ngrok.com/)
# TESTED ON FOLLOWING:-
* Kali Linux - 2020.1a (version)
* Parrot OS - Rolling Edition (version)
* Ubuntu - 18.04 (version)
* Arch Linux
* Termux App
# PREREQUISITES
* sudo - [ MUST ]
* php
* apache2
* ngrok Token
# LANGUAGE 
* Bash Script


# Contact For Contribute & Issues 

                                      EMAIL FOR ISSUES AND CONTRIBUTE : sg5479845@gmail.com

# DISCLAIMER
                                       TO BE USED FOR EDUCATIONAL PURPOSES ONLY

The use of the Adv-Phishing is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program. 


